/* ===========================================================
   Nucleus Software — FinnOne Neo · Gold Loan Audit System
   Shared script — used by every page in this app
   =========================================================== */

/* Cross-file navigation helper — softly fades out before navigating on
   browsers without the View Transitions API; on Chrome/Edge 126+ the
   @view-transition CSS rule (styles.css) handles the crossfade natively. */
function navTo(url) {
  if (typeof document.startViewTransition === "function") {
    location.href = url;
    return;
  }
  document.documentElement.style.transition = "opacity .28s ease";
  document.documentElement.style.opacity = "0";
  setTimeout(function () { location.href = url; }, 260);
}


/* ---------------------------------------------------------
   1. SIDEBAR + TOPBAR CHROME
   Every page calls renderChrome('pageId') once on load.
   This keeps every page a genuinely separate .html file,
   while the nav/topbar/active-state stay perfectly in sync
   across all of them.
--------------------------------------------------------- */
const NAV_ITEMS = [
  { id:'dashboard',  href:'dashboard.html',     icon:'ti-layout-dashboard',  label:'Dashboard' },
  { id:'trigger',    href:'trigger.html',       icon:'ti-file-plus',        label:'Audit Trigger' },
  { id:'sampling',   href:'sampling.html',      icon:'ti-filter',           label:'Branch Sampling' },
  { id:'field',      href:'field.html',         icon:'ti-clipboard-list',   label:'Field Audit' },
  { id:'obs',        href:'observations.html',  icon:'ti-alert-circle',     label:'Observations & NCs' },
  { id:'reports',    href:'reports.html',       icon:'ti-file-description', label:'Reports & Closure' },
];

const BC_LABELS = {
  dashboard:'Dashboard', trigger:'Audit Trigger', sampling:'Branch Sampling',
  field:'Field Audit', obs:'Observations & NCs', reports:'Reports & Closure'
};

function renderChrome(activeId){
  // Sidebar toggle button (mobile)
  const toggle = document.createElement('button');
  toggle.className = 'sidebar-toggle';
  toggle.id = 'sidebar-toggle';
  toggle.innerHTML = '<i class="ti ti-menu-2"></i>';
  toggle.onclick = () => {
    document.getElementById('app-sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('show');
  };
  document.body.appendChild(toggle);

  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay';
  overlay.id = 'sidebar-overlay';
  overlay.onclick = () => {
    document.getElementById('app-sidebar').classList.remove('open');
    overlay.classList.remove('show');
  };
  document.body.appendChild(overlay);

  // Sidebar
  const sidebar = document.createElement('div');
  sidebar.className = 'sidebar';
  sidebar.id = 'app-sidebar';

  const navHtml = NAV_ITEMS.map(item => `
    <a class="nav-item${item.id===activeId ? ' active' : ''}" href="${item.href}">
      <i class="ti ${item.icon}"></i>${item.label}
      <i class="ti ti-chevron-right" style="margin-left:auto;font-size:14px;opacity:0.7"></i>
    </a>`).join('');

  sidebar.innerHTML = `
    <div class="logo-area">
      <div class="logo-box">
        <img class="logo-img" src="assets/nucleus-logo.png" alt="Nucleus Software">
        <div class="logo-text">
          <div class="logo-name">Nucleus Software</div>
          <div class="logo-sub">Exports Ltd.</div>
          <div class="logo-product">FinnOne Neo · Gold Loan Audit</div>
        </div>
      </div>
    </div>
    <div class="nav-section">Audit Workflow</div>
    ${navHtml}
    <div class="user-area">
      <div class="avatar">RK</div>
      <div class="user-info"><div class="un">Rajesh Kumar</div><div class="ur">Audit Manager</div></div>
    </div>`;

  document.body.insertBefore(sidebar, document.body.firstChild);

  // Topbar (inserted at top of .main, if present)
  const topbarMount = document.getElementById('topbar-mount');
  if (topbarMount){
    topbarMount.outerHTML = `
      <div class="topbar">
        <div class="breadcrumb">Home &rsaquo; <span>${BC_LABELS[activeId] || ''}</span></div>
        <div class="topbar-right">
          <button class="btn btn-ghost btn-sm" onclick="navTo('../Merged_Deck_Claude_Bundled.html#slide-command-center')" style="border-color:var(--base-300)"><i class="ti ti-arrow-left"></i>Back to Deck</button>
          <span class="topbar-date"><i class="ti ti-calendar" style="font-size:11px"></i> Oct 01 &ndash; Dec 31, 2024</span>
          <button class="btn btn-gold btn-sm" onclick="location.href='trigger.html'"><i class="ti ti-plus"></i>Initiate New Audit</button>
        </div>
      </div>`;
  }

  // Toast container
  if (!document.getElementById('toast')){
    const t = document.createElement('div');
    t.className = 'toast';
    t.id = 'toast';
    t.innerHTML = '<i class="ti ti-check" style="color:var(--green)"></i><span id="toast-msg"></span>';
    document.body.appendChild(t);
  }
}

/* ---------------------------------------------------------
   2. TOAST
--------------------------------------------------------- */
function toast(msg){
  const t = document.getElementById('toast');
  if (!t) return;
  document.getElementById('toast-msg').textContent = msg;
  t.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => t.classList.remove('show'), 2500);
}

/* ---------------------------------------------------------
   3. TABS (field audit, etc.)
--------------------------------------------------------- */
function switchTab(btn, id){
  btn.closest('.tabs').querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const parent = btn.closest('.content');
  parent.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

/* ---------------------------------------------------------
   4. STEPPER (audit trigger flow)
--------------------------------------------------------- */
function tsNext(s){
  const t = document.getElementById('at-type');
  if (s===1 && t && !t.value){ toast('Please select an audit type'); return; }
  if (s===1){ const rv=document.getElementById('rev-type'); if (rv && t) rv.textContent = t.value; }
  document.getElementById('ts'+s).style.display = 'none';
  document.getElementById('ts'+(s+1)).style.display = 'block';
  document.getElementById('st'+s).classList.remove('active');
  document.getElementById('st'+s).classList.add('done');
  if (document.getElementById('sl'+s)) document.getElementById('sl'+s).classList.add('done');
  document.getElementById('st'+(s+1)).classList.add('active');
}
function tsBack(s){
  document.getElementById('ts'+s).style.display = 'none';
  document.getElementById('ts'+(s-1)).style.display = 'block';
  document.getElementById('st'+s).classList.remove('active');
  document.getElementById('st'+(s-1)).classList.remove('done');
  document.getElementById('st'+(s-1)).classList.add('active');
  if (document.getElementById('sl'+(s-1))) document.getElementById('sl'+(s-1)).classList.remove('done');
}
function submitAudit(){
  toast('Audit submitted — AUD-2025-042 created');
  setTimeout(() => location.href = 'dashboard.html', 1100);
}

/* ---------------------------------------------------------
   5. BRANCH DATA (audit trigger)
--------------------------------------------------------- */
const BD = {
  'Laxmi Nagar': { a:'847', p:'₹42.3Cr', l:'14 Aug 2024', r:'HIGH', c:'DEL-014' },
  'Dwarka':      { a:'612', p:'₹31.1Cr', l:'10 Jun 2024', r:'MED',  c:'DEL-022' },
  'Rohini':      { a:'534', p:'₹28.5Cr', l:'02 Oct 2024', r:'LOW',  c:'DEL-018' },
  'Karol Bagh':  { a:'920', p:'₹51.2Cr', l:'01 Mar 2024', r:'HIGH', c:'DEL-031' },
};
function updateBranch(){
  const b = document.getElementById('at-branch').value;
  const d = BD[b] || BD['Laxmi Nagar'];
  document.getElementById('at-accts').textContent = d.a;
  document.getElementById('at-port').textContent = d.p;
  document.getElementById('at-last').textContent = d.l;
  document.getElementById('at-bcode').value = d.c;
  const rk = document.getElementById('at-risk');
  rk.textContent = d.r;
  rk.className = 'badge ' + (d.r==='HIGH'?'bc':d.r==='MED'?'bm':'bl');
}

/* ---------------------------------------------------------
   6. RADIO CARDS / CHECKBOX HELPERS
--------------------------------------------------------- */
function selRc(el){
  el.closest('.rg').querySelectorAll('.rc').forEach(r => r.classList.remove('sel'));
  el.classList.add('sel');
}
function selAll(cb){
  document.querySelectorAll('#nc-tbody input[type=checkbox]').forEach(c => c.checked = cb.checked);
}

/* ---------------------------------------------------------
   7. PHOTO UPLOAD — "AT LOAN DISBURSEMENT" vs "CURRENT / NOW"
   Photos persist in localStorage per slot id so they survive
   navigating between the separate HTML pages.
--------------------------------------------------------- */
const PHOTO_STORE_KEY = 'glaudit_photos_v1';

function _loadPhotoStore(){
  try { return JSON.parse(localStorage.getItem(PHOTO_STORE_KEY)) || {}; }
  catch(e){ return {}; }
}
function _savePhotoStore(store){
  try { localStorage.setItem(PHOTO_STORE_KEY, JSON.stringify(store)); }
  catch(e){ /* storage full or unavailable — fail silently, photo still shows for this session */ }
}

function triggerUpload(id){
  document.getElementById(id).click();
}

function prevPhoto(inp, slotId){
  if (!inp.files || !inp.files[0]) return;
  const r = new FileReader();
  r.onload = e => {
    _applyPhotoToSlot(slotId, e.target.result);
    const store = _loadPhotoStore();
    store[slotId] = e.target.result;
    _savePhotoStore(store);
    toast('Photo uploaded');
  };
  r.readAsDataURL(inp.files[0]);
}

function _applyPhotoToSlot(slotId, dataUrl){
  const slot = document.getElementById(slotId);
  if (!slot) return;
  let img = slot.querySelector('img');
  if (!img){ img = document.createElement('img'); slot.appendChild(img); }
  img.src = dataUrl;
  slot.classList.add('filled');
  const ic = slot.querySelector('.photo-icon'); if (ic) ic.style.display = 'none';
  let rm = slot.querySelector('.photo-remove');
  if (!rm){
    rm = document.createElement('div');
    rm.className = 'photo-remove';
    rm.innerHTML = '<i class="ti ti-x"></i>';
    rm.onclick = (ev) => { ev.stopPropagation(); removePhoto(slotId); };
    slot.appendChild(rm);
  }
}

function removePhoto(slotId){
  const slot = document.getElementById(slotId);
  if (!slot) return;
  const img = slot.querySelector('img'); if (img) img.remove();
  const rm = slot.querySelector('.photo-remove'); if (rm) rm.remove();
  slot.classList.remove('filled');
  const ic = slot.querySelector('.photo-icon'); if (ic) ic.style.display = '';
  const store = _loadPhotoStore();
  delete store[slotId];
  _savePhotoStore(store);
  toast('Photo removed');
}

// Restore any previously uploaded photos for slots present on this page
function restorePhotos(){
  const store = _loadPhotoStore();
  Object.keys(store).forEach(slotId => {
    if (document.getElementById(slotId)) _applyPhotoToSlot(slotId, store[slotId]);
  });
}

/* ---------------------------------------------------------
   8. NC SIDE PANEL (observations page)
--------------------------------------------------------- */
function showNCPanel(id, acct, cust, cat, sev, desc, by, raised, tgt, status){
  const p = document.getElementById('nc-panel');
  p.style.display = 'block';
  document.getElementById('np-id').textContent = id;
  document.getElementById('np-acct').textContent = acct;
  document.getElementById('np-cust').textContent = cust;
  document.getElementById('np-cat').textContent = cat;
  document.getElementById('np-by').textContent = by;
  document.getElementById('np-tgt').textContent = tgt;
  document.getElementById('np-desc').textContent = desc;
  const sv = document.getElementById('np-sev');
  sv.textContent = sev;
  sv.className = 'badge ' + (sev==='CRITICAL'?'bc':sev==='MAJOR'?'bm':'bl');
  if (window.innerWidth <= 880) p.scrollIntoView({behavior:'smooth'});
}

function filterNC(el, type){
  el.parentElement.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  toast('Filtered: ' + type);
}

/* ---------------------------------------------------------
   9. INIT — runs on every page after chrome is rendered
--------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  restorePhotos();
  const fieldBar = document.getElementById('field-bar');
  if (fieldBar) fieldBar.style.display = 'flex';
});
