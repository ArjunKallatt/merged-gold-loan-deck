/* Nucleus Software — FinnOne Neo · Gold Loan Vaulting System — shared script */
const NAV_GROUPS = [
  {
    section: 'Pre-Auction & LTV',
    items: [
      { id: 'margin', href: 'margin-call-monitoring.html', icon: 'ti-chart-line-down', label: 'Margin Call Monitoring' },
      { id: 'ltv', href: 'ltv-breach-tracking.html', icon: 'ti-scale', label: 'LTV Breach Tracking' }
    ]
  },
  {
    section: 'Auction Operations',
    items: [
      { id: 'auction', href: 'finnone-auction-management-mockup.html', icon: 'ti-gavel', label: 'Recovery Pipeline' },
      { id: 'notices', href: 'notice-automation.html', icon: 'ti-mail-opened', label: 'Notice Automation' },
      { id: 'reval', href: 'purity-revaluation.html', icon: 'ti-zoom-check', label: 'Purity Re-valuation' },
      { id: 'bidding', href: 'live-bidding.html', icon: 'ti-broadcast', label: 'Live Bidding Room' }
    ]
  },
  {
    section: 'Post-Auction',
    items: [
      { id: 'settlement', href: 'settlement-refunds.html', icon: 'ti-cash-banknote', label: 'Settlement & Refunds' },
      { id: 'writeoff', href: 'shortfall-writeoffs.html', icon: 'ti-file-off', label: 'Shortfall Write-offs' }
    ]
  }
];
const NAV_ITEMS = NAV_GROUPS.flatMap(g => g.items);
const BC_LABELS = Object.fromEntries(NAV_ITEMS.map(n => [n.id, n.label]));

function renderChrome(activeId) {
  const toggle = document.createElement('button');
  toggle.className = 'sidebar-toggle'; toggle.innerHTML = '<i class="ti ti-menu-2"></i>';
  toggle.onclick = () => { document.getElementById('app-sidebar').classList.toggle('open'); document.getElementById('sidebar-overlay').classList.toggle('show'); };
  document.body.appendChild(toggle);

  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay'; overlay.id = 'sidebar-overlay';
  overlay.onclick = () => { document.getElementById('app-sidebar').classList.remove('open'); overlay.classList.remove('show'); };
  document.body.appendChild(overlay);

  const sidebar = document.createElement('div');
  sidebar.className = 'sidebar'; sidebar.id = 'app-sidebar';
  const navHtml = NAV_GROUPS.map(g => {
    const isControl = g.section === 'Continuous Control' || g.items.some(i => i.id === 'audit');
    const headerStyle = isControl ? 'color:var(--gold); font-weight:600;' : '';
    return `
    <div class="nav-section" style="${headerStyle}">${g.section}</div>
    ${g.items.map(item => `
      <a class="nav-item${item.id === activeId ? ' active' : ''}" href="${item.href}">
        <i class="ti ${item.icon}"></i>${item.label}
      </a>`).join('')}
  `}).join('');
  
  sidebar.innerHTML = `
    <div class="logo-area"><div class="logo-box">
      <img class="logo-img" src="assets/nucleus-logo.png" alt="Nucleus Software">
      <div class="logo-text"><div class="logo-name">Nucleus Software</div><div class="logo-sub">Exports Ltd.</div>
      <div class="logo-product">FinnOne Neo · Auction Management</div></div>
    </div></div>
    ${navHtml}
    <div class="user-area"><div class="avatar">SM</div><div class="user-info"><div class="un">Suresh Menon</div><div class="ur">Branch Manager · DEL045</div></div></div>`;
  document.body.insertBefore(sidebar, document.body.firstChild);

  const mount = document.getElementById('topbar-mount');
  if (mount) {
    mount.outerHTML = `<div class="topbar">
      <div class="breadcrumb">Home &rsaquo; <span>${BC_LABELS[activeId] || ''}</span></div>
      <div class="topbar-right" style="display:flex; align-items:center; gap:16px;">
        <button class="btn btn-ghost btn-sm" onclick="navTo('../Merged_Deck_Claude_Bundled.html#slide-command-center')" style="border-color:var(--base-300)"><i class="ti ti-arrow-left"></i>Back to Deck</button>
        <label style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; cursor:pointer; color:var(--base-700); background:var(--base-100); padding:4px 10px; border-radius:99px; border:1px solid var(--base-300);">
          <input type="checkbox" id="auditor-toggle" onchange="toggleAuditor(this.checked)"> <i class="ti ti-shield-check"></i> Auditor View
        </label>
        <span class="topbar-date"><i class="ti ti-building-store" style="font-size:11px"></i> Laxmi Nagar · DEL045</span>
        <button class="btn btn-gold btn-sm"><i class="ti ti-file-export"></i>Export Reports</button>
      </div></div>`;
  }
  if (!document.getElementById('toast')) {
    const t = document.createElement('div'); t.className = 'toast'; t.id = 'toast';
    t.innerHTML = '<i class="ti ti-check" style="color:var(--green)"></i><span id="toast-msg"></span>';
    document.body.appendChild(t);
  }
}
function toast(msg) {
  const t = document.getElementById('toast'); if (!t) return;
  document.getElementById('toast-msg').textContent = msg;
  t.classList.add('show'); clearTimeout(window.__tt); window.__tt = setTimeout(() => t.classList.remove('show'), 2500);
}
function toggleAuditor(on) {
  if(on) {
    document.body.classList.add('auditor-mode');
    toast('Auditor Mode Enabled: Showing audit trails and locking actions');
  } else {
    document.body.classList.remove('auditor-mode');
    toast('Auditor Mode Disabled: Operational actions unlocked');
  }
  localStorage.setItem('auditorMode', on);
}
function showModal(title, body, confirmTxt, onConfirm) {
  document.getElementById('sys-modal-title').innerHTML = title;
  document.getElementById('sys-modal-body').innerHTML = body;
  const cb = document.getElementById('sys-modal-confirm');
  cb.innerHTML = confirmTxt || 'Confirm';
  cb.onclick = () => { if(onConfirm) onConfirm(); closeModal(); };
  document.getElementById('sys-modal-overlay').classList.add('show');
}
function closeModal() {
  document.getElementById('sys-modal-overlay').classList.remove('show');
}
function switchTab(btn, id) {
  btn.closest('.tabs').querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const parent = btn.closest('.content');
  parent.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}
function selRc(el) { el.closest('.rg').querySelectorAll('.rc').forEach(r => r.classList.remove('sel')); el.classList.add('sel'); }

/* Vault Explorer — bin click shows detail panel */
const BIN_DATA = {
  'R01-S02-B04': { status: 'General · Date-Wise', fill: '62%', packets: 14, cap: 22, weight: '318g / 500g', last: '2 days ago', flag: null },
  'R01-S02-B05': { status: 'General · Date-Wise', fill: '88%', packets: 19, cap: 22, weight: '447g / 500g', last: 'Today', flag: null },
  'R03-S04-B07': { status: 'General · Date-Wise', fill: '30%', packets: 7, cap: 22, weight: '160g / 500g', last: '5 days ago', flag: null, rec: true },
  'R06-S01-B01': { status: 'NPA / Auction Zone', fill: '71%', packets: 16, cap: 22, weight: '380g / 500g', last: '1 day ago', flag: null },
  'R02-S03-B09': { status: 'General · Date-Wise', fill: '95%', packets: 21, cap: 22, weight: '481g / 500g', last: 'Today', flag: 'Seal exception logged — pending inspection' },
};
function showBin(code, el) {
  if (el) {
    document.querySelectorAll('.bin-3d').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
  }
  const d = BIN_DATA[code] || { status: 'General · Date-Wise', fill: '—', packets: '—', cap: 22, weight: '—', last: '—', flag: null };
  const p = document.getElementById('bin-panel'); if (!p) return;
  p.innerHTML = `
    <div class="bin-panel-title"><i class="ti ti-box-model" style="color:var(--blue-600)"></i> Bin ${code}</div>
    <div class="bin-stat-row"><span>Zone</span><b>${d.status}</b></div>
    <div class="bin-stat-row"><span>Occupancy</span><b>${d.fill}</b></div>
    <div class="bin-stat-row"><span>Packets</span><b>${d.packets} / ${d.cap}</b></div>
    <div class="bin-stat-row"><span>Aggregate Weight</span><b>${d.weight}</b></div>
    <div class="bin-stat-row"><span>Last Audited</span><b>${d.last}</b></div>
    ${d.flag ? `<div class="rec-box" style="background:var(--red-bg);border-color:var(--red-bd);color:var(--red)"><i class="ti ti-alert-triangle"></i> ${d.flag}</div>` : ''}
    ${d.rec ? `<div class="rec-box"><i class="ti ti-sparkles"></i> Recommended for next placement — same pledge date, 30% free, not high-value</div>` : ''}
    <div style="display:flex;gap:6px;margin-top:14px;flex-wrap:wrap">
      <button class="btn btn-gold btn-sm" onclick="toast('Placement logged — dual custody confirmed')">Place Packet Here</button>
      <button class="btn btn-ghost btn-sm" onclick="toast('Opening movement timeline')">View Packets</button>
    </div>`;
}
function filterZone(btn, zoneName) {
  if (btn) {
    btn.closest('.zone-filter').querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
  }
  const racks = document.querySelectorAll('.rack-3d');
  racks.forEach(r => {
    if (zoneName === 'All Zones' || r.getAttribute('data-zone') === zoneName) {
      r.classList.remove('dimmed');
    } else {
      r.classList.add('dimmed');
    }
  });
}

/* Vault Drill-Down Logic */
const VaultDrillDown = {
  level: 'floor', // floor | rack | shelf
  activeRack: null,
  activeShelf: null,

  init: function () {
    this.container = document.getElementById('vault-3d-grid');
    if (!this.container) return;

    // Bind rack clicks
    document.querySelectorAll('.rack-3d').forEach(rack => {
      rack.addEventListener('click', (e) => {
        if (this.level === 'floor') {
          this.zoomToRack(rack);
          e.stopPropagation();
        }
      });
    });

    // Bind shelf clicks
    document.querySelectorAll('.shelf-3d').forEach(shelf => {
      shelf.addEventListener('click', (e) => {
        if (this.level === 'rack') {
          this.zoomToShelf(shelf);
          e.stopPropagation();
        }
      });
    });
  },

  zoomToRack: function (rack) {
    this.level = 'rack';
    this.activeRack = rack;

    // UI Updates
    document.getElementById('crumb-floor').classList.remove('inactive');
    document.getElementById('crumb-rack').classList.remove('hide');
    const rackName = rack.querySelector('.rack-lbl-3d').childNodes[0].textContent.trim();
    document.getElementById('crumb-rack').innerHTML = `<i class="ti ti-server"></i> ${rackName}`;

    // Hide other racks
    document.querySelectorAll('.rack-3d').forEach(r => {
      if (r !== rack) r.classList.add('hidden');
      else {
        r.classList.remove('hidden', 'dimmed');
        r.classList.add('active-drill');
      }
    });

    // Transform container to focus on rack (remove iso rotation, scale up)
    this.container.style.transform = `rotateX(20deg) rotateZ(0deg) scale(1.6) translateY(20px)`;
  },

  zoomToShelf: function (shelf) {
    this.level = 'shelf';
    this.activeShelf = shelf;

    document.getElementById('crumb-rack').classList.remove('inactive');
    document.getElementById('crumb-shelf').classList.remove('hide');
    document.getElementById('crumb-shelf').innerHTML = `<i class="ti ti-layers-linked"></i> Shelf View`;

    // Transform to look closer at the shelf
    this.container.style.transform = `rotateX(5deg) rotateZ(0deg) scale(2.2) translateY(60px)`;
  },

  resetToFloor: function () {
    this.level = 'floor';
    this.activeRack = null;
    this.activeShelf = null;

    document.getElementById('crumb-floor').classList.add('inactive');
    document.getElementById('crumb-rack').classList.add('hide', 'inactive');
    document.getElementById('crumb-shelf').classList.add('hide');

    document.querySelectorAll('.rack-3d').forEach(r => {
      r.classList.remove('hidden', 'active-drill');
    });

    // Re-apply zone filter if active
    const activeFilter = document.querySelector('.filter-chip.active');
    if (activeFilter) filterZone(null, activeFilter.textContent.trim());

    this.container.style.transform = `rotateX(60deg) rotateZ(-45deg) scale(1)`;
  },

  resetToRack: function () {
    if (this.level === 'floor') return;
    this.level = 'rack';
    this.activeShelf = null;

    document.getElementById('crumb-rack').classList.add('inactive');
    document.getElementById('crumb-shelf').classList.add('hide');

    this.container.style.transform = `rotateX(20deg) rotateZ(0deg) scale(1.6) translateY(20px)`;
  }
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('bin-panel')) showBin('R03-S04-B07');
  VaultDrillDown.init();

  if (localStorage.getItem('auditorMode') === 'true') {
    document.body.classList.add('auditor-mode');
    setTimeout(() => {
      const cb = document.getElementById('auditor-toggle');
      if (cb) cb.checked = true;
    }, 100);
  }
  
  const style = document.createElement('style');
  style.innerHTML = `
    body.auditor-mode .btn.btn-primary, body.auditor-mode .btn.btn-gold { opacity: 0.5; pointer-events: none; }
    body.auditor-mode .audit-only { display: block !important; }
    body.auditor-mode .op-only { display: none !important; }
    .audit-only { display: none; }
    
    .sys-modal-overlay { position:fixed; inset:0; background:rgba(17,24,39,0.5); z-index:999; opacity:0; pointer-events:none; transition:opacity .2s; display:flex; align-items:center; justify-content:center; backdrop-filter:blur(2px); }
    .sys-modal-overlay.show { opacity:1; pointer-events:auto; }
    .sys-modal { background:#fff; border-radius:var(--r2); width:440px; max-width:90vw; padding:24px; box-shadow:0 10px 40px rgba(0,0,0,0.2); transform:translateY(20px); transition:transform .3s cubic-bezier(0.16, 1, 0.3, 1); }
    .sys-modal-overlay.show .sys-modal { transform:translateY(0); }
    .sys-modal h3 { margin-bottom:12px; font-size:17px; font-weight:700; color:var(--base-900); display:flex; align-items:center; gap:8px;}
    .sys-modal p { font-size:13.5px; color:var(--base-600); margin-bottom:24px; line-height:1.5; }
    .sys-modal .sys-actions { display:flex; justify-content:flex-end; gap:12px; }
  `;
  document.head.appendChild(style);
  
  const m = document.createElement('div');
  m.id = 'sys-modal-overlay';
  m.className = 'sys-modal-overlay';
  m.innerHTML = '<div class="sys-modal"><h3 id="sys-modal-title">Title</h3><p id="sys-modal-body">Body</p><div class="sys-actions"><button class="btn btn-ghost" onclick="closeModal()">Cancel</button><button class="btn btn-primary" id="sys-modal-confirm">Confirm</button></div></div>';
  document.body.appendChild(m);
});

/* ============================================================
   VAULT EXPLORER v3 — 3-Level Drill Down
   Strongroom -> Vault -> Shelf -> Bin
   ============================================================ */

/* Cross-file navigation helper — softly fades out before navigating on
   browsers without the View Transitions API; on Chrome/Edge 126+ the
   @view-transition CSS rule (styles.css) handles the crossfade natively. */
function navTo(url) {
  if (typeof document.startViewTransition === "function") {
    location.href = url;
    return;
  }
  document.documentElement.style.transition = "opacity .28s ease";
  document.documentElement.style.opacity = "0";
  setTimeout(function () { location.href = url; }, 260);
}

const VAULT_ZONES = {
  general: { label: 'General Storage · Date-wise', color: 'var(--blue-600)', bd: 'var(--blue-300)', bg: 'rgba(37,99,235,.05)' },
  highvalue: { label: 'High-Value (Restricted)', color: 'var(--amber)', bd: 'var(--amber-bd)', bg: 'rgba(245,158,11,.06)' },
  npa: { label: 'Auction / NPA Hold', color: 'var(--red)', bd: 'var(--red-bd)', bg: 'rgba(239,68,68,.06)' },
  quarantine: { label: 'Quarantine', color: '#9333EA', bd: '#D8B4FE', bg: 'rgba(147,51,234,.06)' },
};

/* Seeded RNG for consistent procedural generation */
function seededRandom(seed) {
  let x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

/* Base Vault definitions */
const VAULT_ROOMS = {
  V01: { zone: 'general', x: 60, y: 150, w: 150, h: 120, occ: 68, numShelves: 5, numBins: 24 },
  V02: { zone: 'general', x: 240, y: 150, w: 150, h: 120, occ: 96, alertVault: true, numShelves: 5, numBins: 24 },
  V03: { zone: 'general', x: 420, y: 150, w: 150, h: 120, occ: 41, recommended: true, numShelves: 5, numBins: 24 },
  V05: { zone: 'highvalue', x: 690, y: 150, w: 140, h: 120, occ: 54, numShelves: 4, numBins: 16 },
  V06: { zone: 'npa', x: 690, y: 340, w: 140, h: 110, occ: 71, numShelves: 4, numBins: 16 },
  Q1: { zone: 'quarantine', x: 60, y: 340, w: 100, h: 100, occ: 5, numShelves: 2, numBins: 8 },
};

/* Generate shelves and bins */
Object.entries(VAULT_ROOMS).forEach(([id, v], vIdx) => {
  v.shelves = [];
  let seed = vIdx * 100;
  for (let sIdx = 1; sIdx <= v.numShelves; sIdx++) {
    const shelf = { id: `S${sIdx.toString().padStart(2, '0')}`, bins: [], occ: 0 };
    let filledBins = 0;
    
    for (let bIdx = 1; bIdx <= v.numBins; bIdx++) {
      let r = seededRandom(seed++);
      let fillType = 'free';
      // Bias fill towards vault occ
      if (r < v.occ / 100) {
        let fRnd = seededRandom(seed++);
        if (fRnd > 0.8) fillType = 'b4';
        else if (fRnd > 0.5) fillType = 'b3';
        else if (fRnd > 0.2) fillType = 'b2';
        else fillType = 'b1';
        filledBins++;
      }
      
      // inject some hardcoded bins to ensure BIN_DATA matches
      if (id === 'V01' && shelf.id === 'S02' && bIdx === 4) fillType = 'b3';
      if (id === 'V01' && shelf.id === 'S02' && bIdx === 5) fillType = 'b4';
      if (id === 'V03' && shelf.id === 'S04' && bIdx === 7) fillType = 'b1';
      if (id === 'V06' && shelf.id === 'S01' && bIdx === 1) fillType = 'b4';
      if (id === 'V02' && shelf.id === 'S03' && bIdx === 9) fillType = 'alert';
      
      shelf.bins.push({ n: bIdx.toString().padStart(2, '0'), f: fillType });
    }
    shelf.occ = Math.round((filledBins / v.numBins) * 100);
    v.shelves.push(shelf);
  }
});

const VFP_FILL = { free: 'var(--green)', b1: 'var(--blue-200)', b2: 'var(--blue-400)', b3: 'var(--blue-600)', b4: 'var(--blue-900)', alert: 'var(--red)' };
function vfpOccColor(occ) {
  if (typeof occ !== 'number') return 'var(--amber)';
  if (occ >= 90) return 'var(--red)';
  if (occ >= 70) return 'var(--blue-800)';
  if (occ >= 45) return 'var(--blue-500)';
  return 'var(--blue-300)';
}

const VaultExplorer = {
  vault: null,
  shelf: null,

  init() {
    if (!document.getElementById('vfp-viewport')) return;
    this.renderFloor();
    this.bindZoneFilter();
  },

  bindZoneFilter() {
    document.querySelectorAll('#vfp-zonefilter .filter-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('#vfp-zonefilter .filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        this.applyZoneFilter(chip.dataset.zone);
      });
    });
  },
  applyZoneFilter(zone) {
    document.querySelectorAll('.vfp-vault').forEach(v => {
      const vz = v.getAttribute('data-zone');
      const on = (zone === 'all' || vz === zone);
      v.style.opacity = on ? 1 : 0.18;
      v.style.pointerEvents = on ? 'auto' : 'none';
    });
  },

  crumbs(vaultId, shelfId) {
    const el = document.getElementById('vfp-crumbs');
    if (!el) return;
    if (!vaultId) {
      el.innerHTML = `<span class="vfp-crumb disabled"><i class="ti ti-building-warehouse"></i> Strongroom Floor Plan</span>`;
    } else if (!shelfId) {
      el.innerHTML = `<span class="vfp-crumb" onclick="VaultExplorer.renderFloor()"><i class="ti ti-building-warehouse"></i> Strongroom Floor Plan</span>
        <span class="vfp-crumb-sep">/</span>
        <span class="vfp-crumb disabled"><i class="ti ti-server-2"></i> Vault ${vaultId}</span>`;
    } else {
      el.innerHTML = `<span class="vfp-crumb" onclick="VaultExplorer.renderFloor()"><i class="ti ti-building-warehouse"></i> Strongroom Floor Plan</span>
        <span class="vfp-crumb-sep">/</span>
        <span class="vfp-crumb" onclick="VaultExplorer.openVault('${vaultId}')"><i class="ti ti-server-2"></i> Vault ${vaultId}</span>
        <span class="vfp-crumb-sep">/</span>
        <span class="vfp-crumb disabled">Shelf ${shelfId}</span>`;
    }
  },

  showTip(evt, html) {
    let tip = document.getElementById('vfp-tip');
    if (!tip) { tip = document.createElement('div'); tip.id = 'vfp-tip'; tip.className = 'vfp-tip'; document.body.appendChild(tip); }
    tip.innerHTML = html;
    tip.style.left = evt.clientX + 'px';
    tip.style.top = evt.clientY + 'px';
    tip.style.display = 'block';
  },
  hideTip() { const tip = document.getElementById('vfp-tip'); if (tip) tip.style.display = 'none'; },

  renderFloor() {
    this.vault = null;
    this.shelf = null;
    this.crumbs(null, null);
    const mount = document.getElementById('vfp-viewport');
    if (!mount) return;

    const zoneBoxes = {};
    Object.entries(VAULT_ROOMS).forEach(([id, v]) => {
      if (!zoneBoxes[v.zone]) zoneBoxes[v.zone] = { x1: v.x, y1: v.y, x2: v.x + v.w, y2: v.y + v.h };
      const b = zoneBoxes[v.zone];
      b.x1 = Math.min(b.x1, v.x); b.y1 = Math.min(b.y1, v.y);
      b.x2 = Math.max(b.x2, v.x + v.w); b.y2 = Math.max(b.y2, v.y + v.h);
    });
    const zonesSvg = Object.entries(zoneBoxes).map(([zid, b]) => {
      const z = VAULT_ZONES[zid]; const pad = 16;
      return `<rect x="${b.x1 - pad}" y="${b.y1 - pad - 24}" width="${(b.x2 - b.x1) + pad * 2}" height="${(b.y2 - b.y1) + pad * 2 + 24}" rx="10"
        fill="${z.bg}" stroke="${z.bd}" stroke-width="1.5" stroke-dasharray="6 5"/>
        <text x="${b.x1 - pad + 8}" y="${b.y1 - pad - 8}" class="vfp-zone-lbl" style="fill:${z.color}">${z.label}</text>`;
    }).join('');

    const vaultsSvg = Object.entries(VAULT_ROOMS).map(([id, v]) => {
      const heat = vfpOccColor(v.occ);
      const occTxt = typeof v.occ === 'number' ? v.occ + '% full' : v.occ;
      return `<g class="vfp-vault" data-vault="${id}" data-zone="${v.zone}" tabindex="0" role="button" aria-label="Vault ${id}, ${occTxt}">
        <rect x="${v.x}" y="${v.y}" width="${v.w}" height="${v.h}" rx="8" class="vfp-vault-box" style="fill:${heat};fill-opacity:.15;stroke:${heat};stroke-width:2"/>
        <rect x="${v.x}" y="${v.y}" width="${v.w}" height="7" rx="3" style="fill:${heat}"/>
        <text x="${v.x + v.w / 2}" y="${v.y + v.h / 2 - 4}" class="vfp-vault-id">${id}</text>
        <text x="${v.x + v.w / 2}" y="${v.y + v.h / 2 + 16}" class="vfp-vault-occ" style="fill:${heat}">${occTxt}</text>
        ${v.alertVault ? `<circle cx="${v.x + v.w - 13}" cy="${v.y + 16}" r="8" style="fill:var(--red)"/><text x="${v.x + v.w - 13}" y="${v.y + 20}" class="vfp-alert-mark">!</text>` : ''}
        ${v.recommended ? `<circle class="vfp-rec-badge" cx="${v.x + 13}" cy="${v.y + 16}" r="8" style="fill:var(--green)"/><text x="${v.x + 13}" y="${v.y + 20}" class="vfp-alert-mark">★</text>` : ''}
      </g>`;
    }).join('');

    mount.innerHTML = `<svg viewBox="0 0 880 480" class="vfp-svg">
      <defs><pattern id="vfp-grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M0 0H20V20" fill="none" stroke="var(--base-200)" stroke-width="1"/></pattern></defs>
      <rect x="8" y="8" width="864" height="464" rx="14" fill="url(#vfp-grid)" stroke="var(--base-300)" stroke-width="2"/>
      ${zonesSvg}
      ${vaultsSvg}
      <g transform="translate(420,450)">
        <rect x="-32" y="-6" width="64" height="12" rx="3" style="fill:var(--blue-900)"/>
        <text x="0" y="22" class="vfp-door-lbl">Vault Door · Dual-Custody Entry</text>
      </g>
    </svg>`;

    mount.querySelectorAll('.vfp-vault').forEach(el => {
      const id = el.getAttribute('data-vault'); const v = VAULT_ROOMS[id];
      el.addEventListener('click', () => this.openVault(id));
      el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') this.openVault(id); });
      el.addEventListener('mousemove', e => {
        const occTxt = typeof v.occ === 'number' ? v.occ + '% full' : v.occ;
        this.showTip(e, `<b>Vault ${id}</b><span class="vfp-tip-zone">${VAULT_ZONES[v.zone].label}</span>${occTxt} · click to open`);
      });
      el.addEventListener('mouseleave', () => this.hideTip());
    });

    const activeChip = document.querySelector('#vfp-zonefilter .filter-chip.active');
    this.applyZoneFilter(activeChip ? activeChip.dataset.zone : 'all');
  },

  openVault(vaultId) {
    this.vault = vaultId;
    this.shelf = null;
    this.crumbs(vaultId, null);
    const v = VAULT_ROOMS[vaultId];
    const mount = document.getElementById('vfp-viewport');
    if (!mount || !v) return;

    // Render a list of shelves
    const shelvesHtml = v.shelves.map(s => {
      const heat = vfpOccColor(s.occ);
      const miniBins = s.bins.map(b => `<div class="vfp-smini" style="background:${VFP_FILL[b.f]}"></div>`).join('');
      return `<div class="vfp-shelf-bar" onclick="VaultExplorer.openShelf('${vaultId}', '${s.id}')">
        <div class="vfp-shelf-bar-id">Shelf ${s.id}</div>
        <div class="vfp-shelf-bar-occ">
          <div class="prog-bar" style="max-width:120px;height:8px"><div class="prog-fill" style="width:${s.occ}%;background:${heat}"></div></div>
          <div class="vfp-shelf-bar-occ-txt" style="color:${heat}">${s.occ}% full</div>
        </div>
        <div class="vfp-shelf-bar-mini-bins">${miniBins}</div>
      </div>`;
    }).join('');

    mount.innerHTML = `
      <div class="vfp-mini" onclick="VaultExplorer.renderFloor()" title="Back to floor plan">
        <svg viewBox="0 0 880 480">
          ${Object.entries(VAULT_ROOMS).map(([id, vr]) => `<rect x="${vr.x}" y="${vr.y}" width="${vr.w}" height="${vr.h}" rx="6"
            style="fill:${id === vaultId ? 'var(--blue-600)' : 'var(--base-300)'};opacity:${id === vaultId ? 1 : .55}"/>`).join('')}
        </svg>
        <div class="vfp-mini-lbl">↩ Floor Plan</div>
      </div>
      <div class="vfp-shelf-list" style="padding: 20px; width: 100%; max-width: 600px;">
        <h3 style="margin-bottom:16px;color:var(--base-900);">Vault ${vaultId} Shelves</h3>
        ${shelvesHtml}
      </div>`;
  },
  
  openShelf(vaultId, shelfId) {
    this.vault = vaultId;
    this.shelf = shelfId;
    this.crumbs(vaultId, shelfId);
    const v = VAULT_ROOMS[vaultId];
    const s = v.shelves.find(sh => sh.id === shelfId);
    const mount = document.getElementById('vfp-viewport');
    if (!mount || !v || !s) return;
    
    const shelfTabs = v.shelves.map(sh => `<div class="vfp-shelf-tab ${sh.id === shelfId ? 'active' : ''}" onclick="VaultExplorer.openShelf('${vaultId}', '${sh.id}')">Shelf ${sh.id}</div>`).join('');

    const padTop = 15, padSide = 20, binW = 56, binH = 54, binGap = 10, rowGap = 10;
    const cols = s.bins.length >= 24 ? 8 : (s.bins.length >= 16 ? 8 : 4);
    const rows = Math.ceil(s.bins.length / cols);
    
    const actualCols = Math.min(s.bins.length, cols);
    const shelfW = actualCols * (binW + binGap) - binGap + 16;
    const shelfH = rows * (binH + rowGap) - rowGap + 16;
    
    const svgW = padSide * 2 + shelfW - 16;
    const svgH = padTop + shelfH + 20;

    const binsSvg = s.bins.map((b, bi) => {
      const col = bi % cols;
      const row = Math.floor(bi / cols);
      const x = padSide + col * (binW + binGap);
      const y = padTop + 8 + row * (binH + rowGap);
      const code = `${vaultId}-${s.id}-B${b.n}`;
      return `<rect class="vfp-bin" data-code="${code}" x="${x}" y="${y}" width="${binW}" height="${binH}" rx="6" style="fill:${VFP_FILL[b.f]}"/>
        <text x="${x + binW / 2}" y="${y + binH / 2 + 4}" class="vfp-bin-lbl">${b.n}</text>`;
    }).join('');
    
    const shelfSvg = `<rect class="vfp-elev-shelf" x="${padSide - 8}" y="${padTop}" width="${shelfW}" height="${shelfH}" rx="8"/>
      ${binsSvg}`;

    mount.innerHTML = `
      <div class="vfp-mini" onclick="VaultExplorer.openVault('${vaultId}')" title="Back to vault">
        <svg viewBox="0 0 880 480">
          ${Object.entries(VAULT_ROOMS).map(([id, vr]) => `<rect x="${vr.x}" y="${vr.y}" width="${vr.w}" height="${vr.h}" rx="6"
            style="fill:${id === vaultId ? 'var(--blue-600)' : 'var(--base-300)'};opacity:${id === vaultId ? 1 : .55}"/>`).join('')}
        </svg>
        <div class="vfp-mini-lbl">↩ Vault ${vaultId}</div>
      </div>
      <div style="width:100%;max-width:800px;display:flex;flex-direction:column;">
        <div class="vfp-shelf-tabs">${shelfTabs}</div>
        <svg viewBox="0 0 ${svgW} ${svgH}" class="vfp-svg" style="width:100%;height:auto">
          ${shelfSvg}
        </svg>
      </div>`;

    mount.querySelectorAll('.vfp-bin').forEach(el => {
      const code = el.getAttribute('data-code');
      el.addEventListener('click', () => {
        mount.querySelectorAll('.vfp-bin').forEach(b => b.classList.remove('is-active'));
        el.classList.add('is-active');
        showBin(code, el);
      });
      el.addEventListener('mousemove', e => {
        const d = BIN_DATA[code];
        this.showTip(e, `<b>Bin ${code}</b>${d ? `${d.fill} full · ${d.packets}/${d.cap} packets` : 'Click for placement details'}`);
      });
      el.addEventListener('mouseleave', () => this.hideTip());
    });
  },

  locate(code) {
    const parts = code.split('-');
    if(parts.length !== 3) return;
    const vaultId = parts[0];
    const shelfId = parts[1];
    
    this.renderFloor();
    setTimeout(() => { 
      this.openShelf(vaultId, shelfId); 
      setTimeout(() => {
        const target = document.querySelector(`.vfp-bin[data-code="${code}"]`);
        if (target) { target.classList.add('is-active'); showBin(code, target); }
        toast(`Found ${code} — highlighted in Vault ${vaultId}, Shelf ${shelfId}`);
      }, 50);
    }, 300);
  },
};

document.addEventListener('DOMContentLoaded', () => VaultExplorer.init());